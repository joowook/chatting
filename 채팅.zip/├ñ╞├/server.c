#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <process.h> 

#define BUF_SIZE 200
#define MAX_CLNT 256

typedef struct ClntSock {
    char nname[MAX_CLNT];
    char clnt_ip[BUF_SIZE];
} ClntSock;

unsigned WINAPI HandleClnt(void * arg);
void SendMsg(char * msg, int len, SOCKET hClntSock);
void ErrorHandling(char * msg);
char buf[MAX_CLNT];
char cmp_name[MAX_CLNT];
int clntCnt = 0;
int d = 0;
SOCKET clntSocks[MAX_CLNT];
HANDLE hMutex;

ClntSock c_sock[MAX_CLNT];



int main(int argc, char *argv[])
{
    WSADATA wsaData;
    SOCKET hServSock, hClntSock;
    SOCKADDR_IN servAdr, clntAdr;
    int clntAdrSz;
    HANDLE  hThread;
    int i = 0;
    //int strLen = 0;
    if (argc != 2) {
        printf("Usage : %s <port>\n", argv[0]);
        exit(1);
    }
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
        ErrorHandling("WSAStartup() error!");
    hMutex = CreateMutex(NULL, FALSE, NULL);
    hServSock = socket(PF_INET, SOCK_STREAM, 0);

    memset(&servAdr, 0, sizeof(servAdr));
    servAdr.sin_family = AF_INET;
    servAdr.sin_addr.s_addr = htonl(INADDR_ANY);
    servAdr.sin_port = htons(atoi(argv[1]));

    if (bind(hServSock, (SOCKADDR*)&servAdr, sizeof(servAdr)) == SOCKET_ERROR)
        ErrorHandling("bind() error");
    if (listen(hServSock, 5) == SOCKET_ERROR) //�ο� �� ����
        ErrorHandling("listen() error");

    while (1) {
        clntAdrSz = sizeof(clntAdr);
        hClntSock = accept(hServSock, (SOCKADDR*)&clntAdr, &clntAdrSz);
        
        
        recv(hClntSock, c_sock[i].nname, sizeof(c_sock[i].nname), 0);
        i++;

        WaitForSingleObject(hMutex, INFINITE);
        clntSocks[clntCnt++] = hClntSock;

        ReleaseMutex(hMutex);

        hThread = (HANDLE)_beginthreadex(NULL, 0, HandleClnt,
            (void*)&hClntSock, 0, NULL);
        printf("Connected client IP: %s, �г���: %s \n", inet_ntoa(clntAdr.sin_addr), c_sock[i-1].nname);
        strcpy(c_sock[d++].clnt_ip, inet_ntoa(clntAdr.sin_addr));

    }
    closesocket(hServSock);
    WSACleanup();
    return 0;
}
unsigned WINAPI HandleClnt(void * arg)
{
    SOCKET hClntSock = *((SOCKET*)arg);
    int strLen = 0, i;
    char msg[BUF_SIZE];
    int j = 0;
    while ((strLen = recv(hClntSock, msg, sizeof(msg), 0)) != 0) //recv ���� ����Ʈ �� ���� 
        SendMsg(msg, strLen, hClntSock);

    WaitForSingleObject(hMutex, INFINITE);
    for (i = 0; i<clntCnt; i++)   // remove disconnected client
    {
        if (hClntSock == clntSocks[i])
        {
            while (i++<clntCnt - 1)
                clntSocks[i] = clntSocks[i + 1];
            break;
        }
    }
    clntCnt--;
    ReleaseMutex(hMutex);
    closesocket(hClntSock);
    return 0;

}
void SendMsg(char * msg, int len, SOCKET hClntSock)   // send to all
{
    int i, j = 0, id = 0;
    int count = 1;

 
    WaitForSingleObject(hMutex, INFINITE);
   
    if (!strcmp(msg, "q\n") || !strcmp(msg, "Q\n")) {
        for (i = 0; i<clntCnt; i++)   // remove disconnected client
        {
            if (hClntSock == clntSocks[i])
            {
                while (i++ < clntCnt - 1) {
                    clntSocks[i] = clntSocks[i + 1];
                    strcpy(c_sock[i].nname, c_sock[i + 1].nname);
                    strcpy(c_sock[i].clnt_ip, c_sock[i + 1].clnt_ip);
                }
                break;
            }
        }
        clntCnt--;
        closesocket(hClntSock);
    }
    else {
        for (i = 0; i < clntCnt; i++) {
            if (hClntSock == clntSocks[i])
                id = i;
        }
        i = 0;
        while (msg[count] != ']')
            count++;
        while (msg[count] != ' ')
            count++;
        count++;
        if (msg[count] == '/' && msg[count + 1] == 'h') {
            count += 3;
            while (msg[count] != ' ') { //�������� �� �г���
                cmp_name[j] = msg[count];
                j++;
                count++;
            }
            cmp_name[j] = '\0';

            count++;
            i = 0;
            while (msg[count] != '\n') {
                buf[i] = msg[count];
                i++;
                count++;
            }
            buf[i] = '\n';
            buf[i + 1] = '\0';

            strcpy(msg, "(Whisper) ");
            strcat(msg, "[");
            strcat(msg, c_sock[id].nname);
            strcat(msg, "] ");
            strcat(msg, buf);

            len = strlen(msg);
            for (i = 0; i < clntCnt; i++) {
                if (!strcmp(c_sock[i].nname, cmp_name)) {
                    send(clntSocks[i], msg, len, 0);
                }
            }
        }
        else if (msg[count] == '/' && msg[count + 1] == 'l') {
            strcpy(msg, "������ ����Ʈ, �г��� \n");
            for (int k = 0; k < clntCnt; k++) {
                strcat(msg, "connect client ip: ");
                strcat(msg, c_sock[k].clnt_ip);
                strcat(msg, ", ");
                strcat(msg, c_sock[k].nname);
                strcat(msg, "\n");
                strcat(msg, "\0");
                len = strlen(msg);
                send(clntSocks[id], msg, len, 0);
                strcpy(msg, "");
            }

        }
        else {
            for (i = 0; i < clntCnt; i++) {
                send(clntSocks[i], msg, len, 0);
            }
        }
    }
    ReleaseMutex(hMutex);
}

void ErrorHandling(char * msg)
{
    fputs(msg, stderr);
    fputc('\n', stderr);
    exit(1);
}
